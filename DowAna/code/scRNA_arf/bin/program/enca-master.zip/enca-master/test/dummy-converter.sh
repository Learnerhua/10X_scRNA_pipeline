#! /bin/sh
echo $@
